const mongoose = require('mongoose');
const NotesSchema = new mongoose.Schema({

    userID: {
        type: String,
        required: true
    },
    pname: {
        type: String,
        required: true
    },
    price: {
        type: String,
        required: true
    },
    quantity: {
        type: String,
        required: true
    }

}, { timestamps: true });

const Notes = mongoose.model('Inventories', NotesSchema);
module.exports = Notes;