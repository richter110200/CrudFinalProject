jQuery(function () {
    $(document).on('click', '.edit-button', function () {
        let index = $('.edit-button').index(this);

        let pname = $('.edit-button').eq(index).data('pname');
        let price = $('.edit-button').eq(index).data('price');
        let quantity = $('.edit-button').eq(index).data('quantity');
        let id = $('.edit-button').eq(index).data('id');

        $('#pname').val(pname);
        $('#price').val(price);
        $('#quantity').val(quantity);
        $('.inventory-id').text(`NOTE ID: ${id}`);

        $('#edit-form').attr('action', `/edit-note/${id}`)
    });

    $(document).on('click', '.delete-button', function () {
        let index = $('.delete-button').index(this);

        let pname = $('.delete-button').eq(index).data('pname');
        let price = $('.delete-button').eq(index).data('price');
        let quantity = $('.delete-button').eq(index).data('quantity');
        let id = $('.delete-button').eq(index).data('id');

        $('.note-pname').text(pname);
        $('.note-id').text(`NOTE ID: ${id}`);
        $('#confirm-delete').attr('href', `delete-note/${id}`)
    });
});